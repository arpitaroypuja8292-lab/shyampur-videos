# শ্যামপুর — Remotion প্রজেক্ট (16:9, 1920x1080, 30fps)

    npm install
    npx remotion studio
    npx remotion render Shyampur out/shyampur.mp4

- public/voice.mp3 — ভয়েসওভার, src/cues.ts — SRT থেকে তৈরি টাইমিং (scripts/gen_cues.py)
- src/scenes.tsx — ১৫টি সিন, src/Character.tsx — কোড-আঁকা ক্যারেক্টার

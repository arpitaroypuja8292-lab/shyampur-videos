import React, {createContext, useContext} from 'react';
import {useCurrentFrame} from 'remotion';
import {cues, Cue} from './cues';

export const FPS = 30;
export const W = 1920; // 16:9
export const H = 1080;
export const TOTAL_SEC = 289.907;
export const TOTAL_FRAMES = Math.ceil(TOTAL_SEC * FPS);
export const GY = 985; // ground (feet) y

export const SceneCtx = createContext<{start: number; end: number}>({start: 0, end: 0});
export const useT = () => {
  const f = useCurrentFrame();
  const {start} = useContext(SceneCtx);
  return (f + start) / FPS;
};

export const clamp = (v: number, a = 0, b = 1) => Math.min(b, Math.max(a, v));
export const easeOutBack = (x: number) => {
  x = clamp(x);
  const c1 = 1.70158;
  const c3 = c1 + 1;
  return 1 + c3 * Math.pow(x - 1, 3) + c1 * Math.pow(x - 1, 2);
};
export const pop = (t: number, t0: number, d = 0.35) => (t < t0 ? 0 : easeOutBack((t - t0) / d));
export const fadeIn = (t: number, t0: number, d = 0.3) => clamp((t - t0) / d);
export const fadeOut = (t: number, t1: number, d = 0.3) => clamp((t1 - t) / d);
export const lerp = (t: number, a: number, b: number, v0: number, v1: number) =>
  v0 + (v1 - v0) * clamp((t - a) / (b - a));

export type V<T> = T | ((t: number) => T);
export const rv = <T,>(v: V<T>, t: number): T => (typeof v === 'function' ? (v as (t: number) => T)(t) : v);

export const cueAt = (t: number): Cue | undefined => cues.find((c) => t >= c.start - 0.03 && t <= c.end + 0.08);
export const cueById = (id: number) => cues.find((c) => c.id === id)!;

/** scene start times (seconds) = start of the first cue of each scene */
export const SCENE_FIRST_CUE = [1, 2, 3, 8, 12, 15, 19, 23, 25, 28, 30, 34, 36, 41, 42];
export const sceneStarts = SCENE_FIRST_CUE.map((id, i) => (i === 0 ? 0 : cueById(id).start));

/** Pop-in / pop-out wrapper, positioned by centre point (x, y) */
export const Pop: React.FC<{
  t0: number; t1: number; x: number; y: number; rot?: number; float?: number; children: React.ReactNode;
}> = ({t0, t1, x, y, rot = 0, float = 0, children}) => {
  const t = useT();
  if (t < t0 || t > t1) return null;
  const s = pop(t, t0) * clamp((t1 - t) / 0.25);
  const fy = Math.sin(t * 2.2) * float;
  return (
    <div style={{position: 'absolute', left: x, top: y + fy, transform: `translate(-50%,-50%) rotate(${rot}deg) scale(${s})`, opacity: clamp(s * 2)}}>
      {children}
    </div>
  );
};

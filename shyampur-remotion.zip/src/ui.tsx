import React from 'react';
import {Icon, IconName} from './Icon';
import {Cue} from './cues';
import {clamp, fadeIn, fadeOut, pop, Pop, useT, W, H} from './lib';
import {C, fontFamily} from './theme';
import {WIN, DOOR} from './Bg';

const KEYWORDS = ['বাঁশবাগান', 'বারোটা', 'আতঙ্ক', 'মায়া', 'নিখোঁজ', 'কান্না', 'নূপুর', 'শিকার', 'দরজা', 'ভয়ংকর', 'ঝুম', 'ঠক', 'কঙ্কাল', 'লণ্ঠন', 'আত্মা', 'ক্ষমা', 'প্রতিশোধ', 'সাবস্ক্রাইব', 'লাইক', 'শ্যামপুর', 'মারা', 'জীবিত', 'রাত', 'চিৎকার', 'নীরবতা', 'ঘুম', 'অজ্ঞান', 'বাতাস', 'বিশ', 'শব্দ'];
const isKey = (w: string) => {
  const c = w.replace(/[।,.!?—…\-“”"'‘’]/g, '');
  return c.length > 1 && KEYWORDS.some((k) => c.startsWith(k));
};

export type Chunk = {t0: number; t1: number; words: string[]};
const cache = new Map<number, Chunk[]>();
export const chunkCue = (c: Cue): Chunk[] => {
  if (cache.has(c.id)) return cache.get(c.id)!;
  const words = c.text.split(/\s+/).filter(Boolean);
  const n = Math.ceil(words.length / 5);
  const per = Math.ceil(words.length / n);
  const groups: string[][] = [];
  for (let i = 0; i < words.length; i += per) groups.push(words.slice(i, i + per));
  const tot = groups.reduce((a, g) => a + g.join(' ').length, 0);
  let acc = c.start;
  const out = groups.map((g) => {
    const d = ((c.end - c.start) * g.join(' ').length) / tot;
    const ch = {t0: acc, t1: acc + d, words: g};
    acc += d;
    return ch;
  });
  cache.set(c.id, out);
  return out;
};

export const Caption: React.FC<{cue?: Cue; suppress: [number, number][]}> = ({cue, suppress}) => {
  const t = useT();
  if (!cue || cue.who !== 'N') return null;
  if (suppress.some(([a, b]) => t >= a && t <= b)) return null;
  const ch = chunkCue(cue).find((c) => t >= c.t0 - 0.02 && t < c.t1 + 0.02);
  if (!ch) return null;
  const a = fadeIn(t, ch.t0, 0.2);
  return (
    <>
      <div style={{position: 'absolute', left: 0, right: 0, bottom: 0, height: 260, background: 'linear-gradient(transparent, rgba(0,0,0,.6))'}} />
      <div style={{position: 'absolute', left: 0, right: 0, bottom: 62, textAlign: 'center', fontFamily, fontWeight: 700, fontSize: 64, color: '#fff', opacity: a, transform: `translateY(${(1 - a) * 22}px)`, textShadow: '0 4px 14px rgba(0,0,0,.95), 0 0 4px #000', whiteSpace: 'nowrap'}}>
        {ch.words.map((w, i) => <span key={i} style={{color: isKey(w) ? '#ffd54a' : '#fff'}}>{w}{i < ch.words.length - 1 ? ' ' : ''}</span>)}
      </div>
    </>
  );
};

export const Bubble: React.FC<{cue: Cue; x: number; bottom: number; maya?: boolean}> = ({cue, x, bottom, maya}) => {
  const t = useT();
  const s = pop(t, cue.start - 0.03, 0.3) * clamp((cue.end + 0.08 - t) / 0.12);
  const cx = clamp(x, 470, 1450);
  const tail = clamp(x - cx, -330, 330);
  const bg = maya ? '#14141c' : C.cream;
  const fg = maya ? '#e6f0ff' : '#222';
  const bd = maya ? '#9fb4c8' : '#222';
  return (
    <div style={{position: 'absolute', left: cx, bottom: H - bottom, transform: `translateX(-50%) scale(${s})`, transformOrigin: `${50 + (tail / 8)}% 100%`, opacity: clamp(s * 2)}}>
      <div style={{position: 'relative', maxWidth: 840, width: 'max-content', padding: '22px 34px', borderRadius: 34, background: bg, color: fg, border: `4px solid ${bd}`, fontFamily, fontWeight: 600, fontSize: 42, lineHeight: 1.35, textAlign: 'center', boxShadow: maya ? '0 0 36px rgba(159,180,200,.55)' : '0 8px 22px rgba(0,0,0,.45)'}}>
        {cue.text}
        <div style={{position: 'absolute', left: `calc(50% + ${tail}px)`, bottom: -20, width: 34, height: 34, background: bg, borderRight: `4px solid ${bd}`, borderBottom: `4px solid ${bd}`, transform: 'translateX(-50%) rotate(45deg)'}} />
      </div>
    </div>
  );
};

export const NameBadge: React.FC<{x: number; y: number; t0: number; text: string; color: string}> = ({x, y, t0, text, color}) => {
  const t = useT();
  const t1 = t0 + 2.6;
  if (t < t0 || t > t1) return null;
  const s = pop(t, t0) * clamp((t1 - t) / 0.2);
  return (
    <div style={{position: 'absolute', left: x, top: y, transform: `translate(-50%,-50%) scale(${s})`, padding: '8px 30px', borderRadius: 40, background: color, border: '3px solid #222', fontFamily, fontWeight: 700, fontSize: 40, color: '#fff', boxShadow: '0 6px 16px rgba(0,0,0,.5)', whiteSpace: 'nowrap'}}>{text}</div>
  );
};

export const Stamp: React.FC<{t0: number; t1: number; x: number; y: number; text: string; rot?: number; color?: string; size?: number}> = ({t0, t1, x, y, text, rot = -7, color = '#e03131', size = 84}) => {
  const t = useT();
  if (t < t0 || t > t1) return null;
  const k = clamp((t - t0) / 0.18);
  const s = (1 + (1 - k) * 1.3) * clamp((t1 - t) / 0.25);
  return (
    <div style={{position: 'absolute', left: x, top: y, transform: `translate(-50%,-50%) rotate(${rot}deg) scale(${s})`, opacity: k, padding: '6px 34px', border: `8px solid ${color}`, borderRadius: 14, color, fontFamily, fontWeight: 700, fontSize: size, background: 'rgba(0,0,0,.35)', whiteSpace: 'nowrap', textShadow: '0 0 18px rgba(0,0,0,.6)'}}>{text}</div>
  );
};

export const BigText: React.FC<{t0: number; t1: number; x: number; y: number; text: string; size?: number; color?: string; rot?: number; glow?: string; float?: number}> = ({t0, t1, x, y, text, size = 120, color = '#fff', rot = 0, glow = 'rgba(255,255,255,.4)', float = 0}) => (
  <Pop t0={t0} t1={t1} x={x} y={y} rot={rot} float={float}>
    <div style={{fontFamily, fontWeight: 700, fontSize: size, color, whiteSpace: 'nowrap', textAlign: 'center', textShadow: `0 0 28px ${glow}, 0 6px 16px rgba(0,0,0,.8)`}}>{text}</div>
  </Pop>
);

/** onomatopoeia like  ঝুম / ঠক */
export const SoundText: React.FC<{t0: number; x: number; y: number; text: string; rot?: number; color?: string; size?: number; dur?: number}> = ({t0, x, y, text, rot = -6, color = '#f4d27a', size = 130, dur = 0.9}) => (
  <BigText t0={t0} t1={t0 + dur} x={x} y={y} text={text} size={size} color={color} rot={rot} glow="rgba(244,210,122,.6)" />
);

export const InfoCard: React.FC<{t0: number; t1: number; x: number; y: number; w?: number; h?: number; icon?: IconName; iconLabel?: string; title: string; sub?: string; color?: string; float?: number}> = ({t0, t1, x, y, w = 360, h = 330, icon, iconLabel, title, sub, color = '#74c0fc', float = 6}) => (
  <Pop t0={t0} t1={t1} x={x} y={y} float={float}>
    <div style={{width: w, minHeight: h, boxSizing: 'border-box', padding: '26px 22px', borderRadius: 30, background: 'rgba(16,26,36,.92)', border: `5px solid ${color}`, boxShadow: `0 0 40px ${color}55, 0 14px 30px rgba(0,0,0,.5)`, display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 14, fontFamily, textAlign: 'center'}}>
      {icon && <Icon name={icon} size={130} label={iconLabel} />}
      <div style={{fontSize: 46, fontWeight: 700, color: '#fff', lineHeight: 1.25}}>{title}</div>
      {sub && <div style={{fontSize: 32, fontWeight: 400, color: '#c6d4e0', lineHeight: 1.3}}>{sub}</div>}
    </div>
  </Pop>
);

export const FlashOverlay: React.FC<{at: number; dur?: number; color?: string}> = ({at, dur = 0.35, color = '#fff'}) => {
  const t = useT();
  if (t < at || t > at + dur) return null;
  return <div style={{position: 'absolute', inset: 0, background: color, opacity: 0.85 * (1 - (t - at) / dur)}} />;
};

/** half-buried skeleton (ground at y) */
export const Skeleton: React.FC<{x: number; y: number; at: number; scale?: number}> = ({x, y, at, scale = 1.6}) => {
  const t = useT();
  if (t < at) return null;
  const k = clamp((t - at) / 1.2);
  const rise = (1 - k * k) * 120;
  return (
    <svg width={W} height={H} style={{position: 'absolute', left: 0, top: 0}}>
      <g transform={`translate(${x},${y}) scale(${scale})`}>
        <g transform={`translate(0,${rise})`}>
          <circle cx={0} cy={-78} r={34} fill="#efece0" stroke="#222" strokeWidth={2.5} />
          <rect x={-18} y={-50} width={36} height={16} rx={4} fill="#efece0" stroke="#222" strokeWidth={2.5} />
          <ellipse cx={-12} cy={-82} rx={8} ry={10} fill="#222" /><ellipse cx={12} cy={-82} rx={8} ry={10} fill="#222" /><path d="M0 -72 l-4 10 h8z" fill="#222" />
          <line x1={0} y1={-34} x2={0} y2={30} stroke="#efece0" strokeWidth={9} strokeLinecap="round" />
          {[-20, -6, 8, 22].map((yy, i) => <g key={yy}><path d={`M0 ${yy} Q${-40 + i * 4} ${yy + 4} ${-44 + i * 6} ${yy + 22}`} fill="none" stroke="#efece0" strokeWidth={6} strokeLinecap="round" /><path d={`M0 ${yy} Q${40 - i * 4} ${yy + 4} ${44 - i * 6} ${yy + 22}`} fill="none" stroke="#efece0" strokeWidth={6} strokeLinecap="round" /></g>)}
          <path d="M44 -10 L86 -50 M86 -50 l-10 -14 M86 -50 l2 -16 M86 -50 l12 -10" stroke="#efece0" strokeWidth={6} strokeLinecap="round" fill="none" />
        </g>
        <path d="M-130 20 Q-60 -30 0 -8 Q70 -34 140 20 L150 60 H-140Z" fill="#1d1814" stroke="#0c0907" strokeWidth={2} />
      </g>
    </svg>
  );
};

/** pale figure seen in the house window */
export const WindowGhost: React.FC<{t0: number; t1: number}> = ({t0, t1}) => {
  const t = useT();
  if (t < t0 || t > t1) return null;
  const a = fadeIn(t, t0, 0.8) * fadeOut(t, t1, 0.5) * (0.8 + 0.2 * Math.sin(t * 6));
  return (
    <svg width={W} height={H} style={{position: 'absolute', left: 0, top: 0, opacity: a}}>
      <defs><clipPath id="winclip"><rect x={WIN.x} y={WIN.y} width={WIN.w} height={WIN.h} /></clipPath></defs>
      <g clipPath="url(#winclip)" transform={`translate(${Math.sin(t * 1.5) * 8},${(1 - fadeIn(t, t0, 1)) * 60})`}>
        <path d={`M${WIN.x + 150} ${WIN.y + 90} C${WIN.x + 60} ${WIN.y + 130} ${WIN.x + 50} ${WIN.y + 300} ${WIN.x + 40} ${WIN.y + 380} H${WIN.x + 260} C${WIN.x + 250} ${WIN.y + 300} ${WIN.x + 240} ${WIN.y + 130} ${WIN.x + 150} ${WIN.y + 90}Z`} fill="#f1f4f6" />
        <circle cx={WIN.x + 150} cy={WIN.y + 100} r={42} fill="#e9eff1" />
        <path d={`M${WIN.x + 100} ${WIN.y + 90} C${WIN.x + 100} ${WIN.y + 40} ${WIN.x + 200} ${WIN.y + 40} ${WIN.x + 200} ${WIN.y + 90} C${WIN.x + 190} ${WIN.y + 100} ${WIN.x + 170} ${WIN.y + 120} ${WIN.x + 150} ${WIN.y + 130} C${WIN.x + 130} ${WIN.y + 110} ${WIN.x + 110} ${WIN.y + 100} ${WIN.x + 100} ${WIN.y + 90}Z`} fill="#0b0b10" />
        <ellipse cx={WIN.x + 168} cy={WIN.y + 106} rx={7} ry={9} fill="#050507" />
      </g>
    </svg>
  );
};

/** glowing eyes on the house door */
export const DoorEyes: React.FC<{t0: number; t1: number; color?: string}> = ({t0, t1, color = '#e8f4ff'}) => {
  const t = useT();
  if (t < t0 || t > t1) return null;
  const a = fadeIn(t, t0, 0.5) * fadeOut(t, t1, 0.4);
  const bl = (t * 10) % 7 < 0.25 ? 0.1 : 1;
  return (
    <svg width={W} height={H} style={{position: 'absolute', left: 0, top: 0, opacity: a}}>
      <defs><filter id="eyeglow"><feGaussianBlur stdDeviation="8" /></filter></defs>
      <rect x={DOOR.x + DOOR.w / 2 - 4} y={DOOR.y + 20} width={8} height={DOOR.h - 40} fill={color} opacity={0.35} filter="url(#eyeglow)" />
      {[-38, 38].map((dx) => <g key={dx}><ellipse cx={DOOR.x + DOOR.w / 2 + dx} cy={DOOR.y + 190} rx={22} ry={22 * bl} fill={color} filter="url(#eyeglow)" opacity={0.8} /><ellipse cx={DOOR.x + DOOR.w / 2 + dx} cy={DOOR.y + 190} rx={13} ry={15 * bl} fill="#fff" /></g>)}
      <rect x={DOOR.x} y={DOOR.y + DOOR.h - 6} width={DOOR.w} height={10} fill="#f4c542" opacity={0.5} filter="url(#eyeglow)" />
    </svg>
  );
};

import React from 'react';
import {fontFamily} from './theme';

export type IconName =
  | 'clock' | 'alert' | 'question' | 'moon' | 'door' | 'skull' | 'anklet' | 'bell' | 'like' | 'play'
  | 'calendar' | 'wave' | 'house' | 'ghost' | 'cross' | 'comment' | 'arrow' | 'ring' | 'lock';

const S = {stroke: '#222', strokeWidth: 3.5, strokeLinejoin: 'round', strokeLinecap: 'round'} as const;

export const Icon: React.FC<{name: IconName; size?: number; label?: string}> = ({name, size = 140, label}) => {
  let g: React.ReactNode = null;
  switch (name) {
    case 'clock':
      g = (<>
        <circle cx={50} cy={50} r={42} fill="#f4f1e6" {...S} />
        {[0, 90, 180, 270].map((a) => <line key={a} x1={50} y1={14} x2={50} y2={22} {...S} transform={`rotate(${a} 50 50)`} />)}
        <line x1={50} y1={50} x2={50} y2={30} {...S} strokeWidth={5} />
        <line x1={50} y1={50} x2={50} y2={18} {...S} strokeWidth={4} />
        <circle cx={50} cy={50} r={4} fill="#222" />
      </>);
      break;
    case 'alert':
      g = (<>
        <path d="M50 10 L92 86 L8 86 Z" fill="#f4c542" {...S} />
        <line x1={50} y1={36} x2={50} y2={62} {...S} strokeWidth={7} />
        <circle cx={50} cy={74} r={4.5} fill="#222" />
      </>);
      break;
    case 'question':
      g = (<>
        <circle cx={50} cy={50} r={42} fill="#8e6bd1" {...S} />
        <text x={50} y={72} textAnchor="middle" fontSize={68} fontWeight={800} fill="#fff" fontFamily={fontFamily}>?</text>
      </>);
      break;
    case 'moon':
      g = <path d="M66 12 A40 40 0 1 0 90 66 A32 32 0 1 1 66 12 Z" fill="#f2e9c9" {...S} />;
      break;
    case 'door':
      g = (<>
        <rect x={20} y={8} width={60} height={86} rx={4} fill="#7a5233" {...S} />
        <rect x={28} y={16} width={44} height={32} fill="#8d6240" {...S} strokeWidth={2.5} />
        <rect x={28} y={54} width={44} height={32} fill="#8d6240" {...S} strokeWidth={2.5} />
        <circle cx={68} cy={52} r={4} fill="#f4c542" {...S} strokeWidth={2} />
      </>);
      break;
    case 'lock':
      g = (<>
        <path d="M30 46 V32 A20 20 0 0 1 70 32 V46" fill="none" {...S} strokeWidth={7} />
        <rect x={20} y={44} width={60} height={46} rx={8} fill="#f4c542" {...S} />
        <circle cx={50} cy={64} r={6} fill="#222" />
      </>);
      break;
    case 'skull':
      g = (<>
        <path d="M50 8 C20 8 14 34 24 50 L28 60 L28 74 H72 L72 60 L76 50 C86 34 80 8 50 8 Z" fill="#f1efe6" {...S} />
        <ellipse cx={37} cy={46} rx={9} ry={11} fill="#222" />
        <ellipse cx={63} cy={46} rx={9} ry={11} fill="#222" />
        <path d="M50 54 L45 64 H55 Z" fill="#222" />
        {[38, 46, 54, 62].map((x) => <line key={x} x1={x} y1={66} x2={x} y2={74} {...S} strokeWidth={2.5} />)}
      </>);
      break;
    case 'anklet':
    case 'ring':
      g = (<>
        <ellipse cx={50} cy={52} rx={38} ry={20} fill="none" stroke="#222" strokeWidth={14} />
        <ellipse cx={50} cy={52} rx={38} ry={20} fill="none" stroke="#b8892b" strokeWidth={8} />
        {[-30, -15, 0, 15, 30].map((dx) => <circle key={dx} cx={50 + dx} cy={72 - Math.abs(dx) * 0.12} r={5} fill="#d9a63a" {...S} strokeWidth={2.5} />)}
      </>);
      break;
    case 'bell':
      g = (<>
        <path d="M50 10 C28 10 26 34 24 54 L14 72 H86 L76 54 C74 34 72 10 50 10 Z" fill="#f4c542" {...S} />
        <circle cx={50} cy={82} r={8} fill="#f4a542" {...S} />
      </>);
      break;
    case 'like':
      g = (<>
        <rect x={10} y={44} width={20} height={46} rx={4} fill="#3b82f6" {...S} />
        <path d="M36 48 L50 14 C58 10 66 18 62 30 L60 40 H82 C92 40 94 48 90 56 L86 78 C84 88 78 90 70 90 H36 Z" fill="#ffd166" {...S} />
      </>);
      break;
    case 'play':
      g = (<>
        <rect x={4} y={22} width={92} height={56} rx={16} fill="#e03131" {...S} />
        <path d="M42 36 L66 50 L42 64 Z" fill="#fff" {...S} strokeWidth={3} />
      </>);
      break;
    case 'calendar':
      g = (<>
        <rect x={10} y={16} width={80} height={74} rx={8} fill="#f8f5ea" {...S} />
        <path d="M10 24 A8 8 0 0 1 18 16 H82 A8 8 0 0 1 90 24 V38 H10 Z" fill="#d6453d" {...S} />
        <line x1={30} y1={8} x2={30} y2={24} {...S} strokeWidth={6} />
        <line x1={70} y1={8} x2={70} y2={24} {...S} strokeWidth={6} />
        <text x={50} y={78} textAnchor="middle" fontSize={34} fontWeight={800} fill="#222" fontFamily={fontFamily}>{label ?? '২০'}</text>
      </>);
      break;
    case 'wave':
      g = (<>
        <circle cx={22} cy={50} r={9} fill="#9fb4c8" {...S} />
        {[16, 30, 44].map((r, i) => <path key={r} d={`M${22 + r * 0.55} ${50 - r * 0.8} A${r} ${r} 0 0 1 ${22 + r * 0.55} ${50 + r * 0.8}`} fill="none" stroke="#9fb4c8" strokeWidth={6 - i} strokeLinecap="round" />)}
      </>);
      break;
    case 'house':
      g = (<>
        <path d="M10 48 L50 14 L90 48 Z" fill="#b5523b" {...S} />
        <rect x={20} y={48} width={60} height={42} fill="#e9d8b0" {...S} />
        <rect x={42} y={60} width={16} height={30} fill="#7a5233" {...S} />
      </>);
      break;
    case 'ghost':
      g = (<>
        <path d="M50 8 C26 8 20 28 20 48 V90 L32 80 L42 90 L50 80 L58 90 L68 80 L80 90 V48 C80 28 74 8 50 8 Z" fill="#f4f6f8" {...S} />
        <ellipse cx={39} cy={42} rx={5} ry={8} fill="#222" />
        <ellipse cx={61} cy={42} rx={5} ry={8} fill="#222" />
        <ellipse cx={50} cy={62} rx={6} ry={9} fill="#222" />
      </>);
      break;
    case 'cross':
      g = (<>
        <circle cx={50} cy={50} r={42} fill="#d6453d" {...S} />
        <path d="M32 32 L68 68 M68 32 L32 68" {...S} stroke="#fff" strokeWidth={9} />
      </>);
      break;
    case 'comment':
      g = (<>
        <path d="M14 18 H86 A6 6 0 0 1 92 24 V62 A6 6 0 0 1 86 68 H46 L26 88 V68 H14 A6 6 0 0 1 8 62 V24 A6 6 0 0 1 14 18 Z" fill="#74c0fc" {...S} />
        {[32, 50, 68].map((x) => <circle key={x} cx={x} cy={43} r={5} fill="#fff" />)}
      </>);
      break;
    case 'arrow':
      g = <path d="M8 40 H62 V22 L94 50 L62 78 V60 H8 Z" fill="#f4c542" {...S} />;
      break;
  }
  return <svg width={size} height={size} viewBox="0 0 100 100" style={{overflow: 'visible', filter: 'drop-shadow(0 6px 10px rgba(0,0,0,.45))'}}>{g}</svg>;
};

import React from 'react';
import {Composition} from 'remotion';
import {Video} from './Video';
import {FPS, W, H, TOTAL_FRAMES} from './lib';

export const RemotionRoot: React.FC = () => (
  <Composition id="Shyampur" component={Video} durationInFrames={TOTAL_FRAMES} fps={FPS} width={W} height={H} />
);

import React from 'react';
import {Scene} from './Scene';
import {Icon, IconName} from './Icon';
import {Pop, lerp, fadeIn, clamp} from './lib';
import {BigText, FlashOverlay, InfoCard, SoundText, Skeleton, Stamp, WindowGhost, DoorEyes} from './ui';
import {Expr} from './Character';
import {WIN} from './Bg';
import {fontFamily} from './theme';

const IP: React.FC<{t0: number; t1: number; x: number; y: number; name: IconName; size?: number; rot?: number; float?: number; label?: string}> = ({t0, t1, x, y, name, size = 150, rot = 0, float = 8, label}) => (
  <Pop t0={t0} t1={t1} x={x} y={y} rot={rot} float={float}><Icon name={name} size={size} label={label} /></Pop>
);
/** pick an expression by time-ranges: [[from, expr], ...] */
const ex = (def: Expr, ...r: [number, Expr][]) => (t: number): Expr => {
  let e = def;
  r.forEach(([a, b]) => { if (t >= a) e = b; });
  return e;
};
const NONE: [number, number][] = [[0, 9999]];

/* ───────── 1 · শ্যামপুর পরিচিতি ───────── */
export const S1: React.FC = () => (
  <Scene bg="village" noCaption={[[0.3, 4.9], [8.2, 12]]}>
    <BigText t0={0.5} t1={4.8} x={960} y={400} text="শ্যামপুর" size={250} color="#e8eef3" glow="rgba(159,184,204,.6)" float={6} />
    <BigText t0={1.4} t1={4.8} x={960} y={600} text="একটি ভুতুড়ে গল্প" size={80} color="#ffd54a" glow="rgba(244,197,66,.5)" />
    <IP t0={5.8} t1={8.1} x={1560} y={440} name="alert" size={190} />
    <IP t0={8.3} t1={11.7} x={960} y={380} name="clock" size={250} />
    <Stamp t0={9.4} t1={11.7} x={960} y={680} text="রাত ১২টা — কেউ ফেরে না" size={70} />
  </Scene>
);

/* ───────── 2 · বিশ বছর আগে (মোশন গ্রাফিক্স) ───────── */
const Node: React.FC<{t0: number; x: number; icon: IconName; label?: string; title: string; sub?: string; color: string}> = ({t0, x, icon, label, title, sub, color}) => (
  <InfoCard t0={t0} t1={23.0} x={x} y={540} w={340} h={360} icon={icon} iconLabel={label} title={title} sub={sub} color={color} />
);
export const S2: React.FC = () => (
  <Scene bg="clean" noCaption={NONE}>
    <IP t0={11.9} t1={23.0} x={640} y={160} name="calendar" size={130} />
    <BigText t0={12.0} t1={23.0} x={1070} y={160} text="২০ বছর আগে" size={100} color="#ffd54a" glow="rgba(244,197,66,.45)" />
    <Node t0={12.8} x={300} icon="house" title="গ্রামে বিয়ে" sub="নববধূ মায়া" color="#74c0fc" />
    <IP t0={14.6} t1={23.0} x={520} y={540} name="arrow" size={70} />
    <Node t0={15.2} x={740} icon="calendar" label="৭" title="সাত দিনের মাথায়" color="#ffd43b" />
    <IP t0={17.2} t1={23.0} x={960} y={540} name="arrow" size={70} />
    <Node t0={17.8} x={1180} icon="question" title="রহস্যজনক নিখোঁজ" color="#b197fc" />
    <IP t0={19.6} t1={23.0} x={1400} y={540} name="arrow" size={70} />
    <Node t0={20.2} x={1620} icon="wave" title="মাঝরাতে কান্না" sub="এক মহিলার কান্নার শব্দ" color="#ff8787" />
  </Scene>
);

/* ───────── 3 · চায়ের দোকান: নিতাই কাকা ও রতন ───────── */
export const S3: React.FC = () => (
  <Scene bg="teashop" actors={[
    {kind: 'nitai', x: 520, intro: 23.3, expr: 'worry'},
    {kind: 'rotan', x: 1400, intro: 28.7, expr: ex('neutral', [28.5, 'smile'], [44.6, 'worry'])},
  ]}>
    <IP t0={23.4} t1={28.3} x={960} y={600} name="alert" size={170} />
    <IP t0={28.7} t1={33.0} x={960} y={600} name="ghost" size={170} />
    <IP t0={33.3} t1={39.2} x={960} y={600} name="ghost" size={170} rot={-8} />
    <IP t0={44.8} t1={50.0} x={960} y={600} name="clock" size={170} />
  </Scene>
);

/* ───────── 4 · রতনের ঘর: পায়েল ও রতন ───────── */
export const S4: React.FC = () => (
  <Scene bg="house" actors={[
    {kind: 'payel', x: 520, intro: 50.4, expr: 'scared', tremble: (t) => (t > 63.7 && t < 70.8 ? 1.4 : 0)},
    {kind: 'rotan', x: 1300, expr: ex('neutral', [58.4, 'smile'], [70.9, 'neutral'])},
  ]}>
    <IP t0={50.6} t1={58.2} x={960} y={730} name="wave" size={150} />
    <IP t0={58.5} t1={63.5} x={960} y={730} name="question" size={150} />
    <WindowGhost t0={63.8} t1={70.8} />
    <IP t0={63.9} t1={70.7} x={960} y={730} name="alert" size={150} />
    <IP t0={71.0} t1={75.8} x={960} y={730} name="lock" size={150} />
  </Scene>
);

/* ───────── 5 · বাঁশবাগানে রতন, মায়ার আবির্ভাব ───────── */
export const S5: React.FC = () => (
  <Scene bg="bamboo" noCaption={[[82.3, 84.3]]} actors={[
    {kind: 'rotan', x: (t) => lerp(t, 76.2, 84.0, 250, 820), walk: (t) => t > 76.2 && t < 84.0,
     expr: ex('neutral', [82.6, 'worry'], [84.3, 'scared']), tremble: (t) => (t > 84.3 ? 1.2 : 0)},
    {kind: 'maya', x: 1450, intro: 88.2, expr: 'cold', show: (t) => t >= 87.4, opacity: (t) => fadeIn(t, 87.4, 1.0)},
  ]}>
    <IP t0={76.2} t1={80.5} x={1560} y={330} name="clock" size={190} />
    <SoundText t0={82.4} x={1250} y={380} text="ঝুম..." rot={-8} />
    <SoundText t0={83.0} x={1450} y={530} text="ঝুম..." rot={6} />
    <SoundText t0={83.6} x={1220} y={640} text="ঝুম..." rot={-4} size={150} />
  </Scene>
);

/* ───────── 6 · মায়ার অনুরোধ ───────── */
export const S6: React.FC = () => (
  <Scene bg="bamboo" actors={[
    {kind: 'rotan', x: 560, expr: ex('worry', [107.6, 'scared']), tremble: (t) => (t > 107.6 ? 1.6 : 0)},
    {kind: 'maya', x: 1380, expr: ex('sad', [100.2, 'cold'])},
  ]}>
    <IP t0={100.3} t1={103.5} x={960} y={620} name="question" size={150} />
    <IP t0={103.8} t1={107.4} x={960} y={620} name="house" size={150} />
    <IP t0={107.7} t1={112.8} x={960} y={620} name="alert" size={150} />
  </Scene>
);

/* ───────── 7 · “আমি মায়া!” — খুনের কথা ───────── */
export const S7: React.FC = () => (
  <Scene bg="bamboo" shake={[[117.5, 118.1, 5]]} actors={[
    {kind: 'rotan', x: 560, expr: ex('scared', [117.5, 'shock'], [122.6, 'scared'], [127.0, 'angry']), tremble: 1.8},
    {kind: 'maya', x: 1380, expr: ex('cold', [122.6, 'angry'], [127.0, 'cold']), armR: (t) => (t > 122.6 && t < 126.9 ? 95 : 6)},
  ]}>
    <IP t0={117.6} t1={122.5} x={960} y={620} name="skull" size={160} />
    <IP t0={122.8} t1={126.9} x={960} y={620} name="alert" size={160} />
    <IP t0={127.2} t1={131.7} x={960} y={620} name="cross" size={150} />
  </Scene>
);

/* ───────── 8 · বটগাছ, কঙ্কাল, হরিপদ ───────── */
export const S8: React.FC = () => (
  <Scene bg="banyan" actors={[
    {kind: 'rotan', x: 380, expr: ex('scared', [139.2, 'shock']), tremble: 1.4},
    {kind: 'maya', x: 1000, expr: 'cold', armR: (t) => (t > 131.8 && t < 139 ? 100 : 6)},
    {kind: 'haripada', x: 1700, intro: 139.4, expr: 'scared', tremble: 1.6, show: (t) => t >= 139.1, opacity: (t) => fadeIn(t, 139.1, 0.5)},
  ]}>
    <Skeleton x={1330} y={960} at={132.4} />
    <IP t0={134.5} t1={139.0} x={1200} y={430} name="alert" size={150} />
  </Scene>
);

/* ───────── 9 · হরিপদর স্বীকারোক্তি ───────── */
export const S9: React.FC = () => (
  <Scene bg="banyan" actors={[
    {kind: 'rotan', x: 520, expr: ex('shock', [155.88, 'sad'])},
    {kind: 'haripada', x: 940, expr: ex('scared', [148.1, 'sad']), tremble: 1.2},
    {kind: 'maya', x: 1700, scale: 1.0, expr: 'cold', opacity: 0.85},
  ]}>
    <Skeleton x={1330} y={960} at={0} />
    <IP t0={143.6} t1={147.9} x={730} y={330} name="question" size={140} />
    <IP t0={148.3} t1={155.7} x={730} y={330} name="skull" size={140} />
    <IP t0={156.0} t1={159.8} x={730} y={330} name="cross" size={140} />
  </Scene>
);

/* ───────── 10 · প্রতিশোধের রাত ───────── */
export const S10: React.FC = () => (
  <Scene bg="banyan" shake={[[165.8, 170.5, 7]]}
    tint={(t) => (t > 165.78 ? `rgb(255,${Math.round(120 + 30 * Math.sin(t * 6))},${Math.round(120 + 30 * Math.sin(t * 6))})` : null)}
    actors={[
      {kind: 'haripada', x: 520, expr: 'scared', tremble: 2.6},
      {kind: 'maya', x: 940, expr: ex('cold', [165.78, 'angry']), armL: (t) => (t > 165.78 ? 110 : 4), armR: (t) => (t > 165.78 ? 110 : 6)},
    ]}>
    <Skeleton x={1330} y={960} at={0} />
    <IP t0={165.8} t1={170.5} x={1700} y={250} name="moon" size={200} />
  </Scene>
);

/* ───────── 11 · লণ্ঠন নেভে, ক্ষমা চাওয়া, চিৎকার ───────── */
export const S11: React.FC = () => (
  <Scene bg="banyan" noCaption={[]}
    dark={(t) => (t < 174.6 ? 0.08 : lerp(t, 174.6, 175.4, 0.08, 0.5))}
    shake={[[187.8, 189.4, 12], [172.5, 174.5, 2]]}
    actors={[
      {kind: 'haripada', x: 560, expr: ex('scared', [176.14, 'sad']), lanternOn: (t) => t < 174.6, tremble: 2.2, show: (t) => t < 188.7, opacity: (t) => 1 - fadeIn(t, 188.0, 0.7)},
      {kind: 'maya', x: 1000, expr: ex('cold', [180.96, 'angry'], [187.3, 'cold'])},
    ]}>
    <Skeleton x={1330} y={960} at={0} />
    <FlashOverlay at={187.8} />
  </Scene>
);

/* ───────── 12 · রতন অজ্ঞান, কঙ্কাল ও নূপুর ───────── */
export const S12: React.FC = () => (
  <Scene bg="banyan" noCaption={[[205.8, 209]]} dark={0.1} actors={[
    {kind: 'rotan', x: 160, y: 905, rot: 90, expr: 'faint', scale: 1.05},
    {kind: 'payel', x: 900, expr: 'worry', tremble: 1.2, intro: 193.0},
  ]}>
    <Skeleton x={1330} y={960} at={0} />
    <IP t0={203.4} t1={209.0} x={1620} y={800} name="anklet" size={130} />
    <Stamp t0={206.0} t1={208.8} x={960} y={300} text="নিতাই নিখোঁজ" size={80} />
  </Scene>
);

/* ───────── 13 · রাতে দরজায় ঠক ঠক ───────── */
export const S13: React.FC = () => (
  <Scene bg="house" noCaption={[[212.6, 214.6], [226.0, 229.6], [230.6, 233]]} dark={0.22}
    shake={[[230.9, 231.1, 7], [231.5, 231.7, 7], [232.2, 232.4, 7], [233.2, 233.5, 4]]}
    anchors={{maya: {x: 960, y: WIN.y - 10}, nitai: {x: 1680, y: 290}}}
    actors={[{kind: 'rotan', x: 560, expr: ex('worry', [214.7, 'scared'], [225.5, 'shock']), tremble: (t) => (t > 214.7 ? 1.8 : 0)}]}>
    <SoundText t0={212.7} x={1000} y={760} text="ঝুম..." rot={-6} />
    <SoundText t0={213.4} x={1220} y={700} text="ঝুম..." rot={5} />
    <SoundText t0={214.1} x={900} y={640} text="ঝুম..." rot={-3} size={150} dur={0.7} />
    <WindowGhost t0={214.9} t1={221.2} />
    <DoorEyes t0={221.3} t1={225.4} color="#cfe8ff" />
    <InfoCard t0={226.0} t1={229.5} x={1050} y={560} w={470} h={340} icon="calendar" iconLabel="৩" title="নিতাই কাকা মৃত" sub="তিন দিন আগেই" color="#ff8787" />
    <IP t0={229.6} t1={230.8} x={1050} y={520} name="question" size={190} />
    <SoundText t0={230.8} x={1420} y={420} text="ঠক!" size={150} rot={-6} dur={0.55} />
    <SoundText t0={231.45} x={1330} y={560} text="ঠক!" size={170} rot={5} dur={0.55} />
    <SoundText t0={232.1} x={1250} y={700} text="ঠক!" size={200} rot={-4} dur={0.7} />
    <DoorEyes t0={233.0} t1={236.9} color="#ffb3b3" />
  </Scene>
);

/* ───────── 14 · শিক্ষা — রূপক কার্ড ───────── */
export const S14: React.FC = () => (
  <Scene bg="clean" noCaption={NONE}>
    <BigText t0={237.2} t1={251.8} x={960} y={140} text="মনে রেখো..." size={96} color="#ffd54a" glow="rgba(244,197,66,.5)" />
    <InfoCard t0={238.0} t1={251.8} x={380} y={500} w={400} h={360} icon="clock" title="রাত বারোটার পর" sub="বাঁশবাগানের পথ" color="#74c0fc" />
    <InfoCard t0={241.0} t1={251.8} x={960} y={500} w={400} h={360} icon="anklet" title="নূপুরের শব্দ" sub="ঝুম... ঝুম..." color="#ffd43b" />
    <InfoCard t0={244.0} t1={251.8} x={1540} y={500} w={400} h={360} icon="ghost" title="সাদা শাড়ি পরা মেয়ে" sub="“বাড়ি পৌঁছে দেবেন?”" color="#b197fc" />
    <Stamp t0={247.6} t1={251.8} x={960} y={850} text="সে খুঁজছে পরবর্তী শিকার!" size={88} rot={-3} />
  </Scene>
);

/* ───────── 15 · প্রশ্ন, CTA ও সমাপ্তি ───────── */
const Cta: React.FC<{t0: number; x: number; icon: IconName; title: string; sub: string; color: string}> = ({t0, x, icon, title, sub, color}) => (
  <InfoCard t0={t0} t1={275.2} x={x} y={520} w={360} h={340} icon={icon} title={title} sub={sub} color={color} />
);
export const S15: React.FC = () => (
  <Scene bg="clean" noCaption={NONE} dark={(t) => lerp(t, 288.4, 289.9, 0, 1)}>
    {/* প্রশ্ন কার্ড */}
    <IP t0={252.2} t1={262.4} x={300} y={250} name="moon" size={160} />
    <IP t0={252.6} t1={262.4} x={1620} y={250} name="question" size={160} />
    <Pop t0={252.4} t1={262.4} x={960} y={520} float={5}>
      <div style={{width: 1400, padding: '50px 60px', borderRadius: 40, background: 'rgba(16,26,36,.92)', border: '6px solid #b197fc', boxShadow: '0 0 60px #b197fc66', textAlign: 'center', fontFamily}}>
        <div style={{fontSize: 84, fontWeight: 700, color: '#fff', lineHeight: 1.25}}>আপনার গ্রামেও কি এমন কোনো জায়গা আছে?</div>
        <div style={{fontSize: 56, fontWeight: 600, color: '#ffd54a', marginTop: 22}}>যেখানে রাত বারোটার পর কেউ যেতে সাহস পায় না?</div>
      </div>
    </Pop>
    {/* লাইক · সাবস্ক্রাইব · বেল · কমেন্ট */}
    <Cta t0={264.0} x={260} icon="like" title="লাইক দিন" sub="গল্প ভালো লাগলে" color="#4dabf7" />
    <Cta t0={267.0} x={700} icon="play" title="সাবস্ক্রাইব" sub="চ্যানেলটি সাবস্ক্রাইব করুন" color="#ff6b6b" />
    <Cta t0={270.0} x={1140} icon="bell" title="বেল আইকন" sub="নোটিফিকেশন সবার আগে" color="#ffd43b" />
    <Cta t0={273.0} x={1580} icon="comment" title="কমেন্ট করুন" sub="আপনার মতামত জানান" color="#69db7c" />
    {/* দরজা খুলবেন না */}
    <IP t0={275.5} t1={283.0} x={960} y={400} name="door" size={330} />
    <IP t0={276.0} t1={283.0} x={1080} y={540} name="lock" size={120} />
    <BigText t0={276.2} t1={283.0} x={960} y={760} text="দরজা একদম খুলবেন না!" size={104} color="#ff8a80" glow="rgba(255,138,128,.5)" />
    <SoundText t0={276.8} x={400} y={420} text="ঝুম..." rot={-8} dur={1.2} />
    <SoundText t0={279.0} x={1520} y={380} text="ঝুম..." rot={7} dur={1.2} />
    {/* সমাপ্তি */}
    <BigText t0={283.3} t1={289.9} x={960} y={400} text="আবার দেখা হবে নতুন গল্পে" size={100} color="#e8eef3" />
    <BigText t0={285.2} t1={289.9} x={960} y={620} text="ধন্যবাদ" size={150} color="#ffd54a" glow="rgba(244,197,66,.5)" />
  </Scene>
);

export const SCENES = [S1, S2, S3, S4, S5, S6, S7, S8, S9, S10, S11, S12, S13, S14, S15];
void clamp;

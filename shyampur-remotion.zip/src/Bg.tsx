import React from 'react';
import {AbsoluteFill} from 'remotion';
import {useT, W, H} from './lib';
import {fontFamily} from './theme';

export type BgName = 'village' | 'bamboo' | 'banyan' | 'house' | 'teashop' | 'clean' | 'cleanRed';
export const WIN = {x: 810, y: 250, w: 300, h: 340}; // house window rect
export const DOOR = {x: 1560, y: 330, w: 240, h: 640}; // house door rect

const rng = (s: number) => () => {
  s = (s * 16807) % 2147483647;
  return (s - 1) / 2147483646;
};

const Svg: React.FC<{children: React.ReactNode}> = ({children}) => (
  <svg width={W} height={H} viewBox={`0 0 ${W} ${H}`} style={{position: 'absolute', left: 0, top: 0}}>{children}</svg>
);

const Fog: React.FC<{t: number; opacity?: number; y?: number; color?: string}> = ({t, opacity = 0.32, y = 760, color = '#b9c8d6'}) => (
  <Svg>
    <defs><filter id="fogblur" x="-30%" y="-100%" width="160%" height="300%"><feGaussianBlur stdDeviation="38" /></filter></defs>
    <g filter="url(#fogblur)" opacity={opacity}>
      {[0, 1, 2, 3, 4, 5].map((i) => (
        <ellipse key={i} cx={((i * 430 + t * (16 + (i % 3) * 7)) % 2500) - 280} cy={y + (i % 3) * 60 - 40} rx={400} ry={55} fill={color} />
      ))}
    </g>
  </Svg>
);

const Moon: React.FC<{x: number; y: number; r?: number}> = ({x, y, r = 78}) => (
  <g>
    <circle cx={x} cy={y} r={r * 2.6} fill="#9fb8cc" opacity={0.08} />
    <circle cx={x} cy={y} r={r * 1.6} fill="#b8cde0" opacity={0.12} />
    <circle cx={x} cy={y} r={r} fill="#e8eef3" />
    <circle cx={x - 24} cy={y - 10} r={14} fill="#cdd8e0" /><circle cx={x + 22} cy={y + 24} r={10} fill="#cdd8e0" />
  </g>
);

const Stars: React.FC<{n?: number; t: number}> = ({n = 70, t}) => {
  const r = rng(7);
  return <g>{Array.from({length: n}).map((_, i) => {
    const x = r() * W, y = r() * 520, s = 1 + r() * 2;
    return <circle key={i} cx={x} cy={y} r={s} fill="#dbe7f2" opacity={0.5 + 0.4 * Math.sin(t * 2 + i)} />;
  })}</g>;
};

const Stalk: React.FC<{x: number; bottom: number; top: number; w: number; color: string; sway: number; leaf?: boolean; seed: number}> = ({x, bottom, top, w, color, sway, leaf, seed}) => {
  const joints = Math.floor((bottom - top) / 120);
  return (
    <g transform={`rotate(${sway} ${x} ${bottom})`}>
      <rect x={x - w / 2} y={top} width={w} height={bottom - top} fill={color} />
      {Array.from({length: joints}).map((_, j) => <rect key={j} x={x - w / 2 - 2} y={bottom - (j + 1) * 120} width={w + 4} height={5} fill="#000" opacity={0.35} />)}
      {leaf && [0, 1, 2, 3].map((k) => (
        <ellipse key={k} cx={x + (k - 1.5) * 40} cy={top + 20 + (k % 2) * 40} rx={70} ry={11} fill={color}
          transform={`rotate(${(k - 1.5) * 28 + seed * 5} ${x + (k - 1.5) * 40} ${top + 20 + (k % 2) * 40})`} />
      ))}
    </g>
  );
};

const Vignette: React.FC<{strength?: number}> = ({strength = 0.7}) => (
  <AbsoluteFill style={{background: `radial-gradient(ellipse at 50% 50%, rgba(0,0,0,0) 45%, rgba(0,0,0,${strength}) 100%)`}} />
);

const Sky: React.FC<{id: string; a: string; b: string}> = ({id, a, b}) => (
  <Svg>
    <defs><linearGradient id={id} x1="0" y1="0" x2="0" y2="1"><stop offset="0" stopColor={a} /><stop offset="1" stopColor={b} /></linearGradient></defs>
    <rect width={W} height={H} fill={`url(#${id})`} />
  </Svg>
);

const BambooBG: React.FC<{t: number}> = ({t}) => {
  const r = rng(11);
  const far = Array.from({length: 22}).map((_, i) => ({x: 40 + i * 88 + r() * 40, w: 16 + r() * 8, s: r()}));
  const near = [60, 190, 1740, 1870].map((x, i) => ({x, w: 46 + i % 2 * 10, s: i}));
  return (<>
    <Sky id="sk-b" a="#0c1620" b="#25394a" />
    <Svg><Stars t={t} /><Moon x={1480} y={190} /></Svg>
    <Svg>
      {far.map((s, i) => <Stalk key={i} x={s.x} bottom={860} top={-20} w={s.w} color="#1a2d3c" sway={Math.sin(t * 0.9 + i) * 0.9} leaf seed={s.s} />)}
      <path d="M0 820 L1920 820 L1920 1080 L0 1080Z" fill="#101c26" />
      <path d="M780 820 L1140 820 L1500 1080 L420 1080Z" fill="#26394a" opacity={0.9} />
    </Svg>
    <Fog t={t} y={800} />
    <Svg>{near.map((s, i) => <Stalk key={i} x={s.x} bottom={1100} top={-40} w={s.w} color="#0a131b" sway={Math.sin(t * 0.7 + i * 2) * 0.7} leaf seed={s.s} />)}</Svg>
  </>);
};

const BanyanBG: React.FC<{t: number}> = ({t}) => {
  const r = rng(5);
  return (<>
    <Sky id="sk-y" a="#0b141d" b="#24384a" />
    <Svg><Stars t={t} n={50} /><Moon x={330} y={170} r={68} /></Svg>
    <Svg>
      <path d="M0 850 L1920 850 L1920 1080 L0 1080Z" fill="#111d26" />
      {/* trunk */}
      <path d="M1420 880 C1470 700 1480 500 1470 300 L1650 300 C1640 500 1660 720 1720 880 C1640 900 1500 900 1420 880Z" fill="#2b2420" stroke="#14100d" strokeWidth={3} />
      {[0, 1, 2, 3].map((i) => <path key={i} d={`M${1500 + i * 55} 340 C${1510 + i * 55} 520 ${1500 + i * 55} 700 ${1500 + i * 55} 860`} stroke="#1a1411" strokeWidth={6} fill="none" opacity={0.7} />)}
      {/* canopy */}
      {Array.from({length: 14}).map((_, i) => <circle key={i} cx={700 + i * 100 + r() * 30} cy={110 + r() * 140} r={150 + r() * 80} fill="#0e211e" />)}
      <rect x={600} y={0} width={1320} height={170} fill="#0e211e" />
      {/* hanging roots */}
      {Array.from({length: 16}).map((_, i) => {
        const x = 900 + i * 62 + r() * 20, len = 380 + r() * 320;
        return <path key={i} d={`M${x} 240 q${Math.sin(t * 1.3 + i) * 14} ${len / 2} ${Math.sin(t * 1.1 + i) * 8} ${len}`} stroke="#1a2a24" strokeWidth={5} fill="none" />;
      })}
      <path d="M0 830 q300 -40 600 10 t700 0 t620 -20 V1080 H0Z" fill="#0d1820" />
    </Svg>
    <Fog t={t} y={850} opacity={0.36} />
  </>);
};

const HouseBG: React.FC<{t: number}> = ({t}) => {
  const lampFlick = 0.85 + 0.15 * Math.sin(t * 9) * Math.sin(t * 3.1);
  return (<>
    <Svg>
      <defs>
        <radialGradient id="lamp"><stop offset="0" stopColor="#f4c542" stopOpacity={0.55} /><stop offset="1" stopColor="#f4c542" stopOpacity={0} /></radialGradient>
        <linearGradient id="winsky" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stopColor="#0d1a26" /><stop offset="1" stopColor="#2a4256" /></linearGradient>
      </defs>
      <rect width={W} height={H} fill="#2a3641" />
      {Array.from({length: 24}).map((_, i) => <rect key={i} x={i * 80} y={0} width={4} height={900} fill="#1b242c" opacity={0.7} />)}
      <rect y={900} width={W} height={180} fill="#171f26" />
      <rect y={896} width={W} height={8} fill="#0f151a" />
      {/* window */}
      <rect x={WIN.x - 20} y={WIN.y - 20} width={WIN.w + 40} height={WIN.h + 40} fill="#5e4129" stroke="#222" strokeWidth={3} />
      <rect x={WIN.x} y={WIN.y} width={WIN.w} height={WIN.h} fill="url(#winsky)" />
      <circle cx={WIN.x + 210} cy={WIN.y + 90} r={34} fill="#e8eef3" />
      <rect x={WIN.x + WIN.w / 2 - 5} y={WIN.y} width={10} height={WIN.h} fill="#5e4129" stroke="#222" strokeWidth={2} />
      <rect x={WIN.x} y={WIN.y + WIN.h / 2 - 5} width={WIN.w} height={10} fill="#5e4129" stroke="#222" strokeWidth={2} />
      {/* door */}
      <rect x={DOOR.x - 16} y={DOOR.y - 16} width={DOOR.w + 32} height={DOOR.h + 16} fill="#4a3321" stroke="#222" strokeWidth={3} />
      <rect x={DOOR.x} y={DOOR.y} width={DOOR.w} height={DOOR.h} fill="#6b4a30" stroke="#222" strokeWidth={3} />
      {[1, 2, 3].map((i) => <line key={i} x1={DOOR.x + (DOOR.w / 4) * i} y1={DOOR.y} x2={DOOR.x + (DOOR.w / 4) * i} y2={DOOR.y + DOOR.h} stroke="#3a2818" strokeWidth={4} />)}
      <circle cx={DOOR.x + 40} cy={DOOR.y + 340} r={9} fill="#f4c542" stroke="#222" strokeWidth={2} />
      {/* lantern on the wall (warm light) */}
      <circle cx={330} cy={300} r={380} fill="url(#lamp)" opacity={lampFlick} />
      <line x1={330} y1={0} x2={330} y2={230} stroke="#222" strokeWidth={4} />
      <rect x={300} y={230} width={60} height={80} rx={10} fill="#f4c542" stroke="#222" strokeWidth={3} opacity={lampFlick} />
      <rect x={292} y={222} width={76} height={12} fill="#333" /><rect x={292} y={308} width={76} height={12} fill="#333" />
      {/* tin roof beams */}
      <rect width={W} height={40} fill="#3a2b1e" /><rect y={40} width={W} height={8} fill="#1b140d" />
    </Svg>
  </>);
};

const TeaBG: React.FC<{t: number}> = ({t}) => (
  <>
    <Sky id="sk-t" a="#5d7388" b="#d3b57a" />
    <Svg>
      <path d="M0 640 q300 -110 620 -20 t640 -30 t660 10 V1080 H0Z" fill="#6c6a5c" opacity={0.75} />
      <path d="M0 800 H1920 V1080 H0Z" fill="#5a5148" />
      <path d="M0 800 H1920" stroke="#3d362f" strokeWidth={4} />
      {/* thatched roof */}
      <path d="M0 0 H1920 V210 q-160 70 -330 20 t-330 20 t-330 -20 t-330 20 t-330 -20 t-270 20 Z" fill="#8a6a3b" stroke="#222" strokeWidth={3} />
      {Array.from({length: 40}).map((_, i) => <line key={i} x1={i * 50} y1={20} x2={i * 50 - 24} y2={200} stroke="#6a4f2a" strokeWidth={3} opacity={0.8} />)}
      {/* posts */}
      <rect x={110} y={200} width={30} height={620} fill="#6d5130" stroke="#222" strokeWidth={3} />
      <rect x={1780} y={200} width={30} height={620} fill="#6d5130" stroke="#222" strokeWidth={3} />
      {/* sign */}
      <line x1={880} y1={225} x2={880} y2={290} stroke="#222" strokeWidth={4} /><line x1={1040} y1={225} x2={1040} y2={290} stroke="#222" strokeWidth={4} />
      <rect x={810} y={290} width={300} height={110} rx={10} fill="#c6573a" stroke="#222" strokeWidth={4} />
      <text x={960} y={372} textAnchor="middle" fontSize={84} fontWeight={700} fill="#fff4d6" fontFamily={fontFamily}>চায়ের দোকান</text>
      {/* stove + kettle */}
      <path d="M170 900 V780 H340 V900Z" fill="#8c5a3c" stroke="#222" strokeWidth={3} />
      <rect x={200} y={720} width={110} height={70} rx={14} fill="#9aa3ab" stroke="#222" strokeWidth={3} />
      <path d="M310 740 q50 -40 40 -70" stroke="#222" strokeWidth={8} fill="none" /><path d="M200 740 q-30 -10 -34 -40" stroke="#222" strokeWidth={6} fill="none" />
      <line x1={240} y1={715} x2={270} y2={690} stroke="#222" strokeWidth={5} />
      {[0, 1, 2].map((i) => <ellipse key={i} cx={255 + Math.sin(t * 2 + i) * 14} cy={680 - ((t * 40 + i * 30) % 90)} rx={14} ry={9} fill="#fff" opacity={0.35 - ((t * 40 + i * 30) % 90) / 300} />)}
      {/* bench */}
      <rect x={720} y={840} width={480} height={26} rx={6} fill="#a58450" stroke="#222" strokeWidth={3} />
      {[760, 940, 1140].map((x) => <rect key={x} x={x} y={866} width={22} height={100} fill="#7d6238" stroke="#222" strokeWidth={3} />)}
      <rect x={880} y={800} width={60} height={40} rx={8} fill="#e8d9b5" stroke="#222" strokeWidth={3} />
    </Svg>
    <Fog t={t} y={900} opacity={0.18} color="#f1dfb7" />
  </>
);

const VillageBG: React.FC<{t: number}> = ({t}) => {
  const huts = [150, 480, 790, 1080];
  return (<>
    <Sky id="sk-v" a="#09111a" b="#1f3445" />
    <Svg>
      <Stars t={t} n={90} /><Moon x={560} y={200} r={86} />
      <path d="M0 760 q400 -70 800 0 t1120 -20 V1080 H0Z" fill="#0f1c26" />
      {huts.map((x, i) => (
        <g key={x} transform={`translate(${x} ${720 + (i % 2) * 30})`}>
          <rect x={0} y={30} width={200} height={110} fill="#1a2733" stroke="#06090c" strokeWidth={3} />
          <path d="M-20 34 L100 -40 L220 34Z" fill="#0f171f" stroke="#06090c" strokeWidth={3} />
          <rect x={80} y={60} width={40} height={44} fill={i === 1 || i === 3 ? '#f4c542' : '#0b1118'} opacity={i === 1 || i === 3 ? 0.85 : 1} />
        </g>
      ))}
      {/* bamboo grove at village end */}
      {[1360, 1450, 1540, 1640, 1730, 1830, 1900].map((x, i) => <Stalk key={x} x={x} bottom={900} top={80 + (i % 3) * 40} w={30 + (i % 2) * 8} color="#091219" sway={Math.sin(t + i) * 1.1} leaf seed={i} />)}
      <path d="M0 860 H1920 V1080 H0Z" fill="#0a131b" />
      <path d="M520 1080 L860 860 H1060 L1460 1080Z" fill="#1d2e3b" opacity={0.7} />
    </Svg>
    <Fog t={t} y={820} opacity={0.4} />
  </>);
};

const CleanBG: React.FC<{t: number; red?: boolean}> = ({t, red}) => {
  const r = rng(3);
  return (<>
    <AbsoluteFill style={{background: red ? 'radial-gradient(ellipse at 50% 45%, #3a1a1e 0%, #14090c 75%)' : 'radial-gradient(ellipse at 50% 45%, #22364a 0%, #0a111a 78%)'}} />
    <Svg>{Array.from({length: 34}).map((_, i) => {
      const x = r() * W, y0 = r() * H, sp = 8 + r() * 18;
      return <circle key={i} cx={x + Math.sin(t + i) * 20} cy={(y0 - t * sp + H * 10) % H} r={2 + r() * 3} fill={red ? '#ff9a8a' : '#9fb8cc'} opacity={0.22} />;
    })}</Svg>
    <Fog t={t} y={950} opacity={0.2} color={red ? '#8a3a3a' : '#b9c8d6'} />
  </>);
};

export const Bg: React.FC<{name: BgName}> = ({name}) => {
  const t = useT();
  return (
    <AbsoluteFill>
      {name === 'bamboo' && <BambooBG t={t} />}
      {name === 'banyan' && <BanyanBG t={t} />}
      {name === 'house' && <HouseBG t={t} />}
      {name === 'teashop' && <TeaBG t={t} />}
      {name === 'village' && <VillageBG t={t} />}
      {name === 'clean' && <CleanBG t={t} />}
      {name === 'cleanRed' && <CleanBG t={t} red />}
      <Vignette strength={name === 'teashop' ? 0.45 : 0.7} />
    </AbsoluteFill>
  );
};

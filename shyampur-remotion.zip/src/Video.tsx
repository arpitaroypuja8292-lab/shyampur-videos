import React from 'react';
import {AbsoluteFill, Audio, Sequence, staticFile} from 'remotion';
import {FPS, SceneCtx, TOTAL_FRAMES, sceneStarts} from './lib';
import {SCENES} from './scenes';

const starts = sceneStarts.map((s) => Math.round(s * FPS));

export const Video: React.FC = () => (
  <AbsoluteFill style={{background: '#000'}}>
    {SCENES.map((S, i) => {
      const from = starts[i];
      const end = i + 1 < starts.length ? starts[i + 1] : TOTAL_FRAMES;
      return (
        <Sequence key={i} from={from} durationInFrames={end - from}>
          <SceneCtx.Provider value={{start: from, end}}>
            <S />
          </SceneCtx.Provider>
        </Sequence>
      );
    })}
    <Audio src={staticFile('voice.mp3')} />
  </AbsoluteFill>
);

import React, {useContext} from 'react';
import {AbsoluteFill} from 'remotion';
import {Bg, BgName} from './Bg';
import {Character, Expr, Kind, headTop} from './Character';
import {cueAt, clamp, fadeIn, rv, useT, V, W, SceneCtx} from './lib';
import {Bubble, Caption, NameBadge} from './ui';

export type ActorCfg = {
  kind: Kind; x: V<number>; y?: number; scale?: number; flip?: boolean; expr?: V<Expr>;
  armL?: V<number>; armR?: V<number>; walk?: V<boolean>; tremble?: V<number>; ghost?: boolean;
  lanternOn?: V<boolean>; rot?: number; opacity?: V<number>; intro?: number; lift?: V<number>; show?: V<boolean>;
};

const NAMES: Record<Kind, {label: string; color: string}> = {
  rotan: {label: 'রতন', color: '#2f80c9'},
  maya: {label: 'মায়া', color: '#7b4ab8'},
  haripada: {label: 'হরিপদ', color: '#b5651d'},
  nitai: {label: 'নিতাই কাকা', color: '#3a8f6b'},
  payel: {label: 'পায়েল', color: '#c2417a'},
};

export type SceneProps = {
  bg: BgName;
  actors?: ActorCfg[];
  /** windows (seconds) where the bottom caption must stay hidden because a card/stamp is on screen */
  noCaption?: [number, number][];
  /** [t0, t1, amplitude] screen shake windows */
  shake?: [number, number, number][];
  /** 0..1 darkness overlay over the scene */
  dark?: V<number>;
  /** colour tint overlay: returns css colour or null */
  tint?: (t: number) => string | null;
  /** override bubble anchor (e.g. voice coming from outside the window) */
  anchors?: Partial<Record<Kind, {x: number; y: number}>>;
  children?: React.ReactNode;
};

export const Scene: React.FC<SceneProps> = ({bg, actors = [], noCaption = [], shake = [], dark = 0, tint, anchors, children}) => {
  const t = useT();
  const cue = cueAt(t);
  const f = t * 30;
  let amp = 0;
  shake.forEach(([a, b, k]) => { if (t >= a && t <= b) amp = Math.max(amp, k); });
  const dx = amp ? Math.sin(f * 2.3) * amp : 0;
  const dy = amp ? Math.cos(f * 3.1) * amp : 0;
  const dk = clamp(rv(dark, t));
  const tc = tint ? tint(t) : null;
  const dialogue = cue && cue.who !== 'N' ? cue : undefined;
  const speaker = dialogue?.who;

  const bubble = (() => {
    if (!dialogue) return null;
    const a = actors.find((q) => q.kind === dialogue.who);
    const anc = anchors?.[dialogue.who];
    if (!a && !anc) return null;
    const x = anc ? anc.x : rv(a!.x, t);
    let top = anc ? anc.y : headTop(a!.kind, a!.y ?? 985, a!.scale ?? 1.1, rv(a!.lift ?? 0, t));
    if (a && a.intro !== undefined && t >= a.intro && t < a.intro + 2.6) top -= 62;
    return <Bubble cue={dialogue} x={x} bottom={top - 14} maya={dialogue.who === 'maya'} />;
  })();

  return (
    <AbsoluteFill style={{background: '#000', overflow: 'hidden'}}>
      <div style={{position: 'absolute', left: 0, top: 0, width: W, height: 1080, transform: amp ? `translate(${dx}px,${dy}px) scale(1.04)` : undefined}}>
        <Bg name={bg} />
        <svg width={W} height={1080} style={{position: 'absolute', left: 0, top: 0}}>
          {actors.map((a, i) => {
            if (a.show !== undefined && !rv(a.show, t)) return null;
            return (
              <Character key={i} kind={a.kind} x={rv(a.x, t)} y={a.y} scale={a.scale} flip={a.flip}
                expr={a.expr !== undefined ? rv(a.expr, t) : undefined}
                talking={speaker === a.kind}
                armL={a.armL !== undefined ? rv(a.armL, t) : undefined}
                armR={a.armR !== undefined ? rv(a.armR, t) : undefined}
                walk={a.walk !== undefined ? rv(a.walk, t) : false}
                tremble={a.tremble !== undefined ? rv(a.tremble, t) : 0}
                ghost={a.ghost} lanternOn={a.lanternOn !== undefined ? rv(a.lanternOn, t) : true}
                rot={a.rot} opacity={a.opacity !== undefined ? rv(a.opacity, t) : undefined}
                lift={a.lift !== undefined ? rv(a.lift, t) : 0} seed={i + 2} />
            );
          })}
        </svg>
        {children}
      </div>
      {dk > 0 && <AbsoluteFill style={{background: `rgba(2,5,10,${dk})`}} />}
      {tc && <AbsoluteFill style={{background: tc, mixBlendMode: 'multiply'}} />}
      {actors.filter((a) => a.intro !== undefined).map((a, i) => (
        <NameBadge key={i} x={rv(a.x, t)} y={headTop(a.kind, a.y ?? 985, a.scale ?? 1.1, rv(a.lift ?? 0, t)) - 28} t0={a.intro!} text={NAMES[a.kind].label} color={NAMES[a.kind].color} />
      ))}
      {bubble}
      <Caption cue={cue} suppress={noCaption} />
      <AbsoluteFill style={{background: '#000', opacity: 1 - fadeIn(t, useSceneStart(), 0.25)}} />
    </AbsoluteFill>
  );
};

function useSceneStart() {
  const {start} = useContext(SceneCtx);
  return start / 30;
}

import {loadFont} from '@remotion/google-fonts/HindSiliguri';

export const {fontFamily} = loadFont('normal', {weights: ['400', '600', '700'], subsets: ['bengali', 'latin']});

export const C = {
  ink: '#222222',
  night1: '#0b121a',
  night2: '#14212d',
  night3: '#22343f',
  mist: '#b9c8d6',
  lantern: '#f4c542',
  moon: '#e8eef3',
  blood: '#c0392b',
  cream: '#fdf6e3',
};

import React from 'react';
import {FPS, useT, clamp} from './lib';

export type Expr = 'neutral' | 'smile' | 'sad' | 'scared' | 'angry' | 'shock' | 'cold' | 'worry' | 'faint';
export type Kind = 'rotan' | 'maya' | 'haripada' | 'nitai' | 'payel';

export type CharProps = {
  kind: Kind; x: number; y?: number; scale?: number; flip?: boolean; expr?: Expr; talking?: boolean;
  walk?: boolean; tremble?: number; ghost?: boolean; lanternOn?: boolean; armL?: number; armR?: number;
  rot?: number; opacity?: number; lift?: number; seed?: number;
};

/** relative body height of each character (used for head-top placement too) */
export const KIND_H: Record<Kind, number> = {rotan: 1, maya: 0.95, haripada: 0.93, nitai: 0.9, payel: 0.95};

const O = {stroke: '#222', strokeWidth: 2.5, strokeLinejoin: 'round', strokeLinecap: 'round', vectorEffect: 'non-scaling-stroke'} as const;
const DARK_MOUTH = '#4a1c1c';

type Look = {skin: string; hair: string; brow: string};
const LOOK: Record<Kind, Look> = {
  rotan: {skin: '#b98a63', hair: '#1c1c1c', brow: '#1c1c1c'},
  maya: {skin: '#e9eff1', hair: '#0b0b10', brow: '#0b0b10'},
  haripada: {skin: '#c9a07a', hair: '#e2e2e2', brow: '#9a9a9a'},
  nitai: {skin: '#c9a07a', hair: '#efefef', brow: '#a8a8a8'},
  payel: {skin: '#c08a62', hair: '#15110f', brow: '#15110f'},
};

const Face: React.FC<{kind: Kind; expr: Expr; talking: boolean; f: number; seed: number; ghost: boolean}> = ({kind, expr, talking, f, seed, ghost}) => {
  const L = LOOK[kind];
  const blink = (f + seed * 23) % 110 < 4 && expr !== 'faint';
  const isMaya = kind === 'maya';
  let ry = 16, pr = 6.5, innerB = 0, outerB = 0;
  if (expr === 'scared' || expr === 'shock') { ry = 21; pr = 4; innerB = -12; outerB = -4; if (expr === 'shock') { innerB = -14; outerB = -14; } }
  if (expr === 'angry') { ry = 12; innerB = 11; outerB = -3; }
  if (expr === 'sad' || expr === 'worry') { innerB = -11; outerB = 3; ry = 15; }
  if (expr === 'cold') { ry = 9; innerB = 4; outerB = -2; }
  if (expr === 'smile') { ry = 14; innerB = -3; outerB = -3; }
  const look = Math.sin(f / 40 + seed) * 2.5;
  const eyeY = -478;
  const eye = (sx: number) => {
    if (expr === 'faint') return <path key={sx} d={`M${sx * 24 - 12},${eyeY} q12,10 24,0`} fill="none" stroke="#222" strokeWidth={4} strokeLinecap="round" />;
    const rr = blink ? 1.5 : ry;
    if (isMaya) return (
      <g key={sx}>
        <ellipse cx={sx * 24} cy={eyeY} rx={17} ry={blink ? 1.5 : Math.max(rr + 4, 14)} fill="#050507" stroke="#222" strokeWidth={2} />
        {!blink && <circle cx={sx * 24 + 5} cy={eyeY - 5} r={3.5} fill="#cfe3f3" opacity={0.9} />}
      </g>
    );
    return (
      <g key={sx}>
        <ellipse cx={sx * 24} cy={eyeY} rx={15} ry={rr} fill={ghost ? '#cfd6d8' : '#fff'} {...O} />
        {!blink && !ghost && <circle cx={sx * 24 + look} cy={eyeY + (expr === 'sad' ? 3 : 0)} r={pr} fill="#222" />}
      </g>
    );
  };
  const by = -508;
  const brow = (
    <>
      <path d={`M-42,${by + outerB} L-10,${by + innerB}`} stroke={L.brow} strokeWidth={6} strokeLinecap="round" />
      <path d={`M10,${by + innerB} L42,${by + outerB}`} stroke={L.brow} strokeWidth={6} strokeLinecap="round" />
    </>
  );
  // mouth
  const my = -432;
  const shape = talking ? [0, 1, 2, 1, 0, 2, 1, 0][Math.floor(f / 3 + seed) % 8] : 0;
  let mouth: React.ReactNode;
  if (talking && shape === 1) mouth = <ellipse cx={0} cy={my} rx={10} ry={6} fill={DARK_MOUTH} {...O} />;
  else if (talking && shape === 2) mouth = <ellipse cx={0} cy={my + 2} rx={15} ry={14} fill={DARK_MOUTH} {...O} />;
  else if (expr === 'smile') mouth = <path d={`M-22,${my - 4} Q0,${my + 18} 22,${my - 4}`} fill="none" stroke="#222" strokeWidth={4} strokeLinecap="round" />;
  else if (expr === 'sad') mouth = <path d={`M-16,${my + 6} Q0,${my - 8} 16,${my + 6}`} fill="none" stroke="#222" strokeWidth={4} strokeLinecap="round" />;
  else if (expr === 'scared') mouth = <ellipse cx={0} cy={my + 2} rx={10} ry={13} fill={DARK_MOUTH} {...O} />;
  else if (expr === 'shock') mouth = <ellipse cx={0} cy={my + 4} rx={14} ry={20} fill={DARK_MOUTH} {...O} />;
  else if (expr === 'angry') mouth = <path d={`M-20,${my + 6} Q0,${my - 6} 20,${my + 6}`} fill="none" stroke="#222" strokeWidth={5} strokeLinecap="round" />;
  else if (expr === 'cold') mouth = <path d={`M-20,${my + 2} Q4,${my + 14} 24,${my - 8}`} fill="none" stroke={isMaya ? '#6b2a30' : '#222'} strokeWidth={4} strokeLinecap="round" />;
  else if (expr === 'worry') mouth = <path d={`M-16,${my + 2} q8,-7 16,0 t16,0`} fill="none" stroke="#222" strokeWidth={4} strokeLinecap="round" />;
  else if (expr === 'faint') mouth = <ellipse cx={0} cy={my + 2} rx={8} ry={6} fill={DARK_MOUTH} {...O} />;
  else mouth = <path d={`M-14,${my} L14,${my}`} stroke="#222" strokeWidth={4} strokeLinecap="round" />;
  const tearPhase = ((f * 1.6) % 46);
  return (
    <g>
      {eye(-1)}{eye(1)}{brow}
      {mouth}
      {(expr === 'sad') && [-1, 1].map((s) => <path key={s} d={`M${s * 32},${-466 + tearPhase} q-6,10 0,14 q6,-4 0,-14Z`} fill="#7fc4ff" stroke="#222" strokeWidth={1.5} opacity={1 - tearPhase / 60} />)}
      {(expr === 'scared' || expr === 'shock') && <path d={`M58,${-540 + Math.sin(f / 4) * 4} q-10,16 0,22 q10,-6 0,-22Z`} fill="#8fd0ff" stroke="#222" strokeWidth={1.5} />}
      {kind === 'nitai' && (
        <g fill="rgba(190,225,255,.22)" stroke="#222" strokeWidth={4}>
          <circle cx={-26} cy={eyeY} r={22} /><circle cx={26} cy={eyeY} r={22} />
          <path d={`M-4,${eyeY - 2} q4,-5 8,0`} fill="none" /><path d={`M-48,${eyeY - 2} L-64,${eyeY - 8} M48,${eyeY - 2} L64,${eyeY - 8}`} fill="none" />
        </g>
      )}
    </g>
  );
};

const Hair: React.FC<{kind: Kind}> = ({kind}) => {
  const c = LOOK[kind].hair;
  const cap = 'M-63,-478 C-72,-566 72,-566 63,-478 C45,-500 20,-495 0,-505 C-20,-495 -45,-500 -63,-478 Z';
  if (kind === 'rotan') return <path d={cap} fill={c} {...O} />;
  if (kind === 'payel') return (
    <g>
      <path d={'M-65,-470 C-76,-570 76,-570 65,-470 C60,-510 30,-526 0,-526 C-30,-526 -60,-510 -65,-470 Z'} fill={c} {...O} />
      <rect x={-3} y={-540} width={6} height={20} fill="#d6322c" />
    </g>
  );
  if (kind === 'haripada') return (
    <g>
      <path d={'M-62,-470 C-72,-550 72,-550 62,-470 C50,-520 -50,-520 -62,-470 Z'} fill={c} {...O} />
    </g>
  );
  if (kind === 'nitai') return <path d={'M-62,-470 C-70,-545 70,-545 62,-470 C48,-520 -48,-520 -62,-470 Z'} fill={c} {...O} />;
  // maya: front hair curtain over half the face
  return (
    <g>
      <path d={'M-68,-470 C-76,-570 76,-570 68,-470 C62,-520 30,-528 8,-524 C-2,-470 -18,-420 -30,-376 C-58,-398 -74,-432 -68,-470Z'} fill={c} {...O} />
      <path d={'M44,-520 C60,-480 66,-440 58,-400'} stroke={c} strokeWidth={10} fill="none" strokeLinecap="round" />
    </g>
  );
};

const Arm: React.FC<{side: 1 | -1; angle: number; skin: string; sleeve: string | null; sleeveLen?: number; children?: React.ReactNode; bangles?: boolean}> = ({side, angle, skin, sleeve, sleeveLen = 90, children, bangles}) => (
  <g transform={`translate(${side * 70},-372) rotate(${side === -1 ? angle : -angle})`}>
    <rect x={-15} y={-8} width={30} height={158} rx={15} fill={skin} {...O} />
    {sleeve && <rect x={-16.5} y={-10} width={33} height={sleeveLen} rx={16} fill={sleeve} {...O} />}
    {bangles && <g><rect x={-15} y={118} width={30} height={7} fill="#fff" {...O} strokeWidth={1.5} /><rect x={-15} y={127} width={30} height={7} fill="#c0392b" {...O} strokeWidth={1.5} /><rect x={-15} y={136} width={30} height={7} fill="#fff" {...O} strokeWidth={1.5} /></g>}
    <circle cx={0} cy={160} r={17} fill={skin} {...O} />
    {children}
  </g>
);

const Leg: React.FC<{x: number; angle: number; color: string; shoe?: boolean}> = ({x, angle, color, shoe = true}) => (
  <g transform={`translate(${x},-175) rotate(${angle})`}>
    <rect x={-18} y={0} width={36} height={172} rx={18} fill={color} {...O} />
    {shoe && <ellipse cx={4} cy={174} rx={28} ry={12} fill="#2b2b2b" {...O} />}
  </g>
);

export const Character: React.FC<CharProps> = (p) => {
  const t = useT();
  const f = t * FPS;
  const {kind} = p;
  const L = LOOK[kind];
  const seed = p.seed ?? kind.length;
  const expr = p.expr ?? 'neutral';
  const maya = kind === 'maya';
  const lift = (p.lift ?? 0) + (maya ? 70 : 0) + (p.ghost ? 40 : 0);
  const bob = Math.sin(t * 2.1 + seed) * (maya || p.ghost ? 11 : 4) + (p.walk ? Math.abs(Math.sin(t * 7)) * -8 : 0);
  const jit = p.tremble ? Math.sin(f * 2.9 + seed) * p.tremble : 0;
  const jit2 = p.tremble ? Math.cos(f * 3.7) * p.tremble * 0.6 : 0;
  const sc = (p.scale ?? 1.1) * KIND_H[kind];
  const swing = p.walk ? Math.sin(t * 7) : 0;
  const talkSwing = p.talking && p.armR === undefined ? 18 + Math.sin(t * 7 + seed) * 14 : 0;
  const aR = p.armR ?? (p.walk ? -swing * 22 : talkSwing);
  const aL = p.armL ?? (p.walk ? swing * 22 : 4);
  const lean = kind === 'nitai' ? 8 : kind === 'haripada' ? 4 : 0;
  const body = (() => {
    switch (kind) {
      case 'rotan': return (
        <>
          <path d="M-62,-205 L62,-205 L78,-18 L-78,-18 Z" fill="#4f6d7a" {...O} />
          {[-40, -13, 14, 41].map((x) => <line key={x} x1={x * 0.85} y1={-205} x2={x * 1.1} y2={-18} stroke="#33505c" strokeWidth={3} />)}
          {[-150, -100, -55].map((y) => <line key={y} x1={-70} y1={y} x2={70} y2={y} stroke="#33505c" strokeWidth={3} />)}
          <rect x={-64} y={-405} width={128} height={235} rx={40} fill="#7d5a4f" {...O} />
          {[[-30, -350], [20, -330], [-10, -280], [35, -250], [-40, -230], [0, -380], [-35, -310]].map(([x, y], i) => <circle key={i} cx={x} cy={y} r={7} fill="#d4aa80" />)}
        </>
      );
      case 'maya': return (
        <>
          <path d="M-64,-405 L64,-405 L74,-175 L98,-34 L78,-52 L58,-24 L38,-56 L18,-28 L-2,-56 L-22,-26 L-42,-54 L-62,-26 L-98,-44 L-74,-175Z" fill="#f1f4f6" {...O} />
          <path d="M-30,-300 l8,34 M20,-220 l-6,40 M-50,-160 l6,60 M40,-330 l10,28" stroke="#9aa6ae" strokeWidth={3} fill="none" />
          <path d="M-64,-405 L64,-405 L58,-350 L-58,-350Z" fill="#e3e9ec" {...O} />
          {[-22, 22].map((x) => <g key={x}>
            <ellipse cx={x} cy={-26} rx={18} ry={14} fill="#e9eff1" {...O} />
            <ellipse cx={x} cy={-34} rx={20} ry={6} fill="none" stroke="#9c7a2c" strokeWidth={5} />
            {[-12, 0, 12].map((d) => <circle key={d} cx={x + d} cy={-24 + Math.abs(d) * 0.1} r={3.5} fill="#8a6a22" />)}
          </g>)}
        </>
      );
      case 'haripada': return (
        <>
          <path d="M-62,-205 L62,-205 L74,-18 L-74,-18 Z" fill="#ece8dc" {...O} />
          <path d="M-8,-205 L-6,-30 M16,-205 L20,-30" stroke="#c8c2b0" strokeWidth={3} />
          <rect x={-64} y={-405} width={128} height={235} rx={38} fill="#b8a07a" {...O} />
          <line x1={0} y1={-402} x2={0} y2={-175} stroke="#7a6746" strokeWidth={3} />
          {[-360, -320, -280].map((y) => <circle key={y} cx={0} cy={y} r={5} fill="#5a4a30" />)}
        </>
      );
      case 'nitai': return (
        <>
          <path d="M-62,-205 L62,-205 L72,-18 L-72,-18 Z" fill="#f4f1ea" {...O} />
          <rect x={-64} y={-405} width={128} height={235} rx={38} fill="#dad7cc" {...O} />
          <path d="M-72,-395 C-40,-420 40,-420 72,-395 L82,-250 L50,-190 L-20,-300 L-50,-190 L-82,-250Z" fill="#f7f5ef" {...O} />
          <path d="M-72,-395 L-82,-250 M72,-395 L82,-250" stroke="#8a8a82" strokeWidth={6} />
        </>
      );
      case 'payel': return (
        <>
          <path d="M-62,-205 L62,-205 L80,-18 L-80,-18 Z" fill="#4e7f86" {...O} />
          <path d="M-80,-18 L80,-18 L79,-38 L-79,-38Z" fill="#e0b84c" {...O} strokeWidth={2} />
          <rect x={-64} y={-405} width={128} height={235} rx={38} fill="#4e7f86" {...O} />
          <path d="M-60,-400 L-20,-408 L66,-220 L30,-172 Z" fill="#3d666c" {...O} />
          <path d="M-60,-400 L-20,-408 L66,-220" stroke="#e0b84c" strokeWidth={6} fill="none" />
        </>
      );
    }
  })();
  const sleeve = kind === 'rotan' ? '#7d5a4f' : kind === 'haripada' ? '#b8a07a' : kind === 'nitai' ? '#f7f5ef' : kind === 'payel' ? '#4e7f86' : null;
  const legColor = kind === 'rotan' ? L.skin : kind === 'payel' ? L.skin : L.skin;
  const hands = (side: 1 | -1) => {
    if (kind === 'haripada' && side === 1) {
      const lit = p.lanternOn ?? true;
      return (
        <g transform={`rotate(${side === 1 ? aR : 0})`}>
          <line x1={0} y1={160} x2={0} y2={190} stroke="#222" strokeWidth={4} />
          {lit && <circle cx={0} cy={235} r={90} fill="#f4c542" opacity={0.28 + Math.sin(f / 5) * 0.04} />}
          <rect x={-22} y={188} width={44} height={64} rx={8} fill={lit ? '#ffd966' : '#5b5648'} {...O} />
          <rect x={-26} y={182} width={52} height={10} fill="#333" /><rect x={-26} y={250} width={52} height={10} fill="#333" />
        </g>
      );
    }
    if (kind === 'nitai' && side === -1) return <rect x={-6} y={150} width={12} height={226} rx={6} fill="#6d4c2f" {...O} />;
    return null;
  };
  const opacity = p.opacity ?? (p.ghost ? 0.82 : 1);
  return (
    <g transform={`translate(${p.x + jit2},${(p.y ?? 985)})`} opacity={opacity}>
      {(p.rot ?? 0) === 0 && <ellipse cx={0} cy={4} rx={95 * sc} ry={14 * sc} fill="rgba(0,0,0,.3)" />}
      <g transform={`rotate(${p.rot ?? 0}) scale(${(p.flip ? -1 : 1) * sc},${sc}) translate(${jit},${-lift + bob})`}
        style={p.ghost ? {filter: 'grayscale(.85) brightness(1.2)'} : undefined}>
        {maya && <circle cx={0} cy={-290} r={260} fill="#cfe3f3" opacity={0.045 + Math.sin(t * 2) * 0.015} />}
        {maya && <path d="M-82,-500 C-130,-400 -118,-250 -96,-120 L96,-120 C118,-250 130,-400 82,-500 Z" fill={L.hair} {...O} />}
        {kind === 'payel' && <path d="M52,-440 C112,-420 118,-330 96,-210" stroke="#15110f" strokeWidth={22} fill="none" strokeLinecap="round" />}
        {!maya && <>
          <Leg x={-26} angle={swing * 20} color={legColor} />
          <Leg x={26} angle={-swing * 20} color={legColor} />
        </>}
        <g transform={`rotate(${lean} 0 -175)`}>
          {body}
          <Arm side={-1} angle={aL} skin={L.skin} sleeve={sleeve} sleeveLen={kind === 'payel' ? 90 : 100} bangles={kind === 'payel'}>{hands(-1)}</Arm>
          <Arm side={1} angle={aR} skin={L.skin} sleeve={sleeve} sleeveLen={kind === 'payel' ? 90 : 100} bangles={kind === 'payel'}>{hands(1)}</Arm>
          {kind === 'rotan' && <path d="M-64,-398 L-24,-408 L64,-262 L32,-236Z" fill="#c0392b" {...O} />}
          {kind === 'rotan' && <path d="M-40,-372 L-20,-380 L52,-268 M-52,-352 L-30,-362 L42,-250" stroke="#fff" strokeWidth={3} fill="none" opacity={0.8} />}
          <ellipse cx={-62} cy={-468} rx={10} ry={16} fill={L.skin} {...O} /><ellipse cx={62} cy={-468} rx={10} ry={16} fill={L.skin} {...O} />
          <ellipse cx={0} cy={-470} rx={62} ry={70} fill={L.skin} {...O} />
          {kind === 'rotan' && <path d="M-44,-440 Q0,-398 44,-440" fill="none" stroke="#3a2a22" strokeWidth={6} opacity={0.55} strokeLinecap="round" />}
          {kind === 'haripada' && <path d="M-58,-452 C-54,-366 54,-366 58,-452 C36,-418 -36,-418 -58,-452 Z" fill="#ececec" {...O} />}
          <Face kind={kind} expr={expr} talking={!!p.talking} f={f} seed={seed} ghost={!!p.ghost} />
          <Hair kind={kind} />
        </g>
      </g>
    </g>
  );
};
export const headTop = (kind: Kind, y: number, scale: number, lift = 0) => y - lift - (kind === 'maya' ? 70 : 0) - 560 * KIND_H[kind] * scale;
void clamp;

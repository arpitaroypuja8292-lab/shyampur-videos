import re,json,sys
who="N N nitai rotan nitai rotan nitai payel rotan payel rotan N rotan N maya rotan maya rotan maya rotan maya rotan maya haripada rotan haripada rotan haripada maya N haripada maya N payel N N maya nitai N maya N N N N N".split()
raw=open('public/voice.srt',encoding='utf-8').read().strip().split('\n\n')
def sec(s):
    h,m,r=s.split(':');s2,ms=r.split(',');return int(h)*3600+int(m)*60+int(s2)+int(ms)/1000
out=[]
for b in raw:
    l=b.split('\n');i=int(l[0]);a,c=l[1].split(' --> ')
    out.append(dict(id=i,start=sec(a),end=sec(c),who=who[i-1],text=' '.join(l[2:])))
assert len(out)==45==len(who)
open('src/cues.ts','w',encoding='utf-8').write("export type Who = 'N' | 'rotan' | 'maya' | 'haripada' | 'nitai' | 'payel';\nexport type Cue = {id:number; start:number; end:number; who:Who; text:string};\nexport const cues: Cue[] = "+json.dumps(out,ensure_ascii=False,indent=1)+";\n")
